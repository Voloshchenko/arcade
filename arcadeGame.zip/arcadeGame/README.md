#Arcade game

##How to start playing
1.Download this file on your computer.
2.Open this folder.
3.Find file called "index".
4.Run it in your browser. 

##How to play it.
####Main goal to reach the river avoiding the cockroaches.
*Control: keyboard "up", "down", "left", "right".
*You can collect the golden sars, they gives you 10 points.
*Every time you're running into the cockroaches you lose 1 point and returning to the starting point.
*Every time you're reaching the river you get 1 point and returning to the starting point.
*There are 4 four levels, each time you get to new level cockroaches start to move faster.
